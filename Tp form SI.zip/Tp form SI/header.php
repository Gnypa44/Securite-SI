<header>
<div id="head">


    <div id="menu"><a href="index.php"><img src="img/logo.png" id="flecheMenu" alt="logo menu"></a></div>


</div>
</header>